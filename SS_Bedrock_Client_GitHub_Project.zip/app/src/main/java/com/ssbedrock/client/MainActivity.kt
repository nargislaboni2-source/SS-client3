package com.ssbedrock.client

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 13, 28)
    private val panel = Color.rgb(17, 29, 54)
    private val blue = Color.rgb(45, 145, 255)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showWelcome()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun baseColumn(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(24))
            setBackgroundColor(bg)
        }
    }

    private fun text(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
    }

    private fun button(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(white)
            setBackgroundColor(blue)
            setOnClickListener { action() }
        }
    }

    private fun showWelcome() {
        val root = baseColumn()
        root.gravity = Gravity.CENTER
        root.addView(text("SS", 48f, blue, true))
        root.addView(text("Welcome to SS Client", 25f, white, true))
        root.addView(text("Bedrock companion app", 14f, Color.LTGRAY))
        val launch = button("LAUNCH") { showDashboard() }
        val params = LinearLayout.LayoutParams(-1, dp(56))
        params.topMargin = dp(30)
        root.addView(launch, params)
        setContentView(root)
    }

    private fun showDashboard() {
        val scroll = ScrollView(this)
        val root = baseColumn()
        root.addView(text("SS BEDROCK CLIENT", 23f, blue, true))
        root.addView(text("SS Blue Glow Theme  •  Version 1.0", 12f, Color.LTGRAY))
        addSection(root, "PvP & HUD", listOf(
            "FPS Counter", "CPS Counter", "Custom Crosshair", "PvP HUD",
            "3rd Person Gamer Tag", "Air Swing", "Hotbar Key Buttons",
            "KMS Controls", "Hit Color", "Direction HUD"
        ))
        addSection(root, "Performance & Visuals", listOf(
            "Dynamic Lights", "Online AFK", "Minimap", "Zoom", "Replay Mod"
        ))
        addSection(root, "Chat & Social", listOf(
            "Proximity Voice Chat", "Proximity Text Chat", "Java-style Chat"
        ))
        addSection(root, "Customization", listOf(
            "Custom Texture Packs", "Custom Skin", "Custom UI"
        ))
        addSection(root, "SS Smart Features", listOf(
            "SS Client AI"
        ))
        root.addView(button("OPEN MINECRAFT") { openMinecraft() }, LinearLayout.LayoutParams(-1, dp(54)).apply {
            topMargin = dp(18)
        })
        root.addView(text("Note: These switches are UI placeholders in this first APK. They do not modify Minecraft yet.", 12f, Color.LTGRAY))
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun addSection(root: LinearLayout, title: String, items: List<String>) {
        val heading = text(title, 18f, blue, true)
        heading.gravity = Gravity.START
        val hp = LinearLayout.LayoutParams(-1, -2)
        hp.topMargin = dp(24)
        root.addView(heading, hp)

        items.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setBackgroundColor(panel)
            }
            val label = TextView(this).apply {
                text = item
                textSize = 14f
                setTextColor(white)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val toggle = Switch(this).apply {
                isChecked = false
                setOnCheckedChangeListener { _, checked ->
                    Toast.makeText(this@MainActivity,
                        if (checked) "$item: UI enabled" else "$item: UI disabled",
                        Toast.LENGTH_SHORT).show()
                }
            }
            row.addView(label)
            row.addView(toggle)
            val rp = LinearLayout.LayoutParams(-1, -2)
            rp.topMargin = dp(6)
            root.addView(row, rp)
        }
    }

    private fun openMinecraft() {
        val intent = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (intent != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, "Minecraft is not installed or its package was not found.", Toast.LENGTH_LONG).show()
        }
    }
}
